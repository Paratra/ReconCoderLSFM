# -*- coding: utf-8 -*-
"""
Created on Tue Apr 17 12:54:02 2018

@author: rl74173
"""

import numpy as np
import tiffile as tf


